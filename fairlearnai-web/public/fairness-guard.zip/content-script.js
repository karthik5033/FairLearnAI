(function() {
  'use strict';
  
  console.log("🛡️ Fairness Guard v6.0 - FRESH LOAD");

  try {
    // Signal presence to web app
    if (window.location.href.includes("localhost:3000")) {
      const marker = document.createElement('div');
      marker.id = 'fairness-guard-installed';
      marker.style.display = 'none';
      document.body.appendChild(marker);
      window.dispatchEvent(new CustomEvent('FAIRNESS_GUARD_DETECTED'));
      console.log("🛡️ Signaled to FairLearnAI");
    }

    // Show blocking overlay
    function showBlockedOverlay(message, suggestion) {
      console.log("🛡️ Showing overlay:", message);
      
      const existing = document.getElementById('fg-overlay');
      if (existing) existing.remove();
      
      const backdrop = document.createElement('div');
      backdrop.id = 'fg-overlay';
      backdrop.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.8);z-index:999999;display:flex;align-items:center;justify-content:center;';
      
      const modal = document.createElement('div');
      modal.style.cssText = 'background:white;padding:40px;border-radius:20px;max-width:500px;text-align:center;border:4px solid #ef4444;box-shadow:0 0 50px rgba(0,0,0,0.5);';
      modal.innerHTML = `
        <div style="font-size:60px;margin-bottom:20px;">⚠️</div>
        <h2 style="color:#111;font-size:24px;margin:0 0 15px 0;font-weight:700;">Action Blocked</h2>
        <p style="color:#666;font-size:16px;margin:0 0 20px 0;line-height:1.6;">${message}</p>
        ${suggestion ? `<div style="background:#f3f4f6;padding:15px;border-radius:10px;margin-bottom:20px;"><p style="margin:0;color:#374151;font-size:14px;"><strong>Try instead:</strong><br/>"${suggestion}"</p></div>` : ''}
        <button id="fg-close" style="background:#111;color:white;border:none;padding:15px 30px;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;">I Understand</button>
      `;
      
      backdrop.appendChild(modal);
      document.body.appendChild(backdrop);
      
      document.getElementById('fg-close').onclick = () => backdrop.remove();
      backdrop.onclick = (e) => { if (e.target === backdrop) backdrop.remove(); };
    }

    // Get prompt text
    function getPrompt() {
      const el = document.querySelector('#prompt-textarea') || 
                 document.querySelector('textarea') ||
                 document.querySelector('[contenteditable="true"]');
      if (el) {
        return (el.value || el.textContent || el.innerText || '').trim();
      }
      return '';
    }

    // Clear input
    function clearPrompt() {
      const el = document.querySelector('#prompt-textarea') || 
                 document.querySelector('textarea') ||
                 document.querySelector('[contenteditable="true"]');
      if (el) {
        if ('value' in el) el.value = '';
        if ('textContent' in el) el.textContent = '';
        if ('innerText' in el) el.innerText = '';
      }
    }

    // Main checking logic
    async function checkAndBlock(event, prompt) {
      console.log("🛡️ Intercepting:", prompt.substring(0, 30));
      
      // 1. Check Keywords (Fast Client-Side)
      const lower = prompt.toLowerCase();
      const keywords = ['essay', 'summary', 'write a', 'solve this'];
      let blocked = false;
      
      for (const k of keywords) {
        if (lower.includes(k)) {
          blocked = true;
          break;
        }
      }

      // 2. If valid, check API (Async Background)
      if (!blocked) {
        await new Promise(resolve => {
          try {
            chrome.runtime.sendMessage({ type: 'CHECK_PROMPT', prompt }, (res) => {
              if (res && res.classification !== 'ALLOWED') blocked = true;
              resolve();
            });
          } catch (e) { resolve(); }
        });
      }

      if (blocked) {
        console.log("🛡️ ❌ BLOCKED!");
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        clearPrompt();
        showBlockedOverlay("This request violates academic integrity policies.", "Try asking for hints instead.");
        return true;
      }
      return false;
    }

    // Intercept clicks
    document.addEventListener('click', async function(e) {
      const btn = e.target.closest('button');
      if (!btn) return;
      
      if (btn.querySelector('svg') || (btn.getAttribute('aria-label')||'').includes('send')) {
        const prompt = getPrompt();
        if (prompt) await checkAndBlock(e, prompt);
      }
    }, true);

    // Intercept Enter
    document.addEventListener('keydown', async function(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        const prompt = getPrompt();
        if (prompt) await checkAndBlock(e, prompt);
      }
    }, true);

    console.log("🛡️ ✅ Ready");

    // Visual indicator
    setInterval(() => {
      const input = document.querySelector('#prompt-textarea, textarea');
      if (input && !input.hasAttribute('data-fg')) {
        input.style.outline = '3px solid #10b981';
        input.setAttribute('data-fg', '1');
      }
    }, 2000);

  } catch (error) {
    console.error("🛡️ ERROR:", error);
  }
})();
